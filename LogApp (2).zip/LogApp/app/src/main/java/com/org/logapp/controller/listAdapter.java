package com.org.logapp.controller;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.org.logapp.R;
import com.org.logapp.model.DataModel;
import com.org.logapp.view.OnFragmentInteractionListener;
import com.org.logapp.view.ItemUI;

import java.util.ArrayList;
import java.util.List;

public class listAdapter  extends ArrayAdapter<DataModel> implements Filterable {

    LayoutInflater inflater;
    OnFragmentInteractionListener m_listener;
    Context context;
    private List<DataModel> objects;
    private Filter filter;

    public listAdapter(Context context, int resource, List<DataModel> objects) {
        super(context, resource, objects);
        inflater = LayoutInflater.from(context);
        this.context = context;
        this.objects = objects;
        m_listener = (OnFragmentInteractionListener)context;
    }

    private class ViewHolder {
        LinearLayout item_area;
        TextView title_area;
        TextView place_area;
        TextView date_area;

    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final DataModel item = getItem(position);

        listAdapter.ViewHolder holder = null;

        holder = new listAdapter.ViewHolder();

        convertView = inflater.inflate(R.layout.layout_list_item, null);
        holder.item_area = convertView.findViewById(R.id.item_area);
        holder.title_area = convertView.findViewById(R.id.title_area);
        holder.place_area = convertView.findViewById(R.id.place_area);
        holder.date_area = convertView.findViewById(R.id.date_area);

        holder.title_area.setText(item.title + " Km");
        holder.place_area.setText(item.place);
        holder.date_area.setText(item.date);


        holder.item_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ItemUI.flag = false;
                ItemUI.model = item;
                m_listener.changeFragment(2);
            }
        });

        return convertView;
    }

    @Override
    public Filter getFilter() {
        if (filter == null)
            filter = new listAdapter.AppFilter<DataModel>(objects);
        return filter;
    }

    private class AppFilter<T> extends Filter {

        private ArrayList<T> sourceObjects;

        public AppFilter(List<T> objects) {
            sourceObjects = new ArrayList<T>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }

        @Override
        protected FilterResults performFiltering(CharSequence chars) {
            String filterSeq = chars.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (filterSeq != null && filterSeq.length() > 0) {
                ArrayList<T> filter = new ArrayList<T>();

                for (T object : sourceObjects) {
                    // the filtering itself:
                    String category = ((DataModel)object).title;
                    if (category.toLowerCase().contains(filterSeq))
                        filter.add(object);
                }
                result.count = filter.size();
                result.values = filter;
            } else {
                // add all objects
                synchronized (this) {
                    result.values = sourceObjects;
                    result.count = sourceObjects.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {
            // NOTE: this function is *always* called from the UI thread.
            ArrayList<T> filtered = (ArrayList<T>) results.values;
            notifyDataSetChanged();
            clear();
            for (int i = 0, l = filtered.size(); i < l; i++)
                add((DataModel) filtered.get(i));
            notifyDataSetInvalidated();
        }
    }
    private void startIntent(Class<?> cls){
        Intent intent = new Intent(context, cls);
        context.startActivity(intent);
    }
}