package com.org.logapp.view;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.org.logapp.R;
import com.org.logapp.model.DBHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.org.logapp.controller.StorageController;
import com.org.logapp.model.DataModel;

import static android.app.Activity.RESULT_OK;

public class ItemUI extends Fragment implements View.OnClickListener {
    EditText title_area;
    EditText place_area;
    EditText detail_area;
    TextView date_area;
    TextView lat_area;
    TextView lon_area;

    Button map_show_btn;
    Button share_btn;
    Button remove_btn;

    ImageView image_view;
    FloatingActionButton camera_btn;

    private LocationManager mLocationManager;

    private OnFragmentInteractionListener mListener;

    SimpleDateFormat date_format;
    Calendar newCalenda;

    private static final int CAMERA_REQUEST = 1888;
    private String image_path = "";

    private DBHelper db;

    public static boolean flag = true;
    public static DataModel model;
    private int id = -1;

    public ItemUI() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.activity_item_ui_view, container, false);
        title_area = view.findViewById(R.id.title_area);
        place_area = view.findViewById(R.id.place_area);
        detail_area = view.findViewById(R.id.detail_area);
        date_area = view.findViewById(R.id.date_area);
        date_area.setText(getCurrentDay());
        date_area.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_RIGHT = 2;

                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (date_area.getRight() - date_area.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        setDate();
                        return true;
                    }
                }
                return false;
            }
        });
        lat_area = view.findViewById(R.id.lat_area);
        lon_area = view.findViewById(R.id.lon_area);

        map_show_btn = view.findViewById(R.id.show_map_btn);
        map_show_btn.setOnClickListener(this);

        share_btn = view.findViewById(R.id.share_btn);
        share_btn.setOnClickListener(this);

        remove_btn = view.findViewById(R.id.remove_btn);
        remove_btn.setOnClickListener(this);


        image_view = view.findViewById(R.id.image_view);
        camera_btn = view.findViewById(R.id.camera_btn);
        camera_btn.setOnClickListener(this);

        date_format = new SimpleDateFormat("yyyy/MM/dd");
        newCalenda = Calendar.getInstance();

        db = new DBHelper(getActivity());

        mLocationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if(flag){
            Location current_location = getLastBestLocation();
            if(current_location != null){
                lat_area.setText(String.valueOf(current_location.getLatitude()));
                lon_area.setText(String.valueOf(current_location.getLongitude()));
            }
        }

        if(!flag){
            setParams();
        }
        return view;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            //m_context = context;
            mListener = (OnFragmentInteractionListener) context;
            image_path = "";
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    public void onClick(View view){
        if(view == camera_btn){
            takePictureFromCamera();
        }else if(view == share_btn){
            AlertDialog.Builder adb = new AlertDialog.Builder(getActivity());
            adb.setTitle("Are you want to save this data ?");
            adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    save();
                }
            });
            adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    mListener.changeFragment(1);
                }
            });
            adb.show();
        }else if(view == map_show_btn){
            showMap();
        }else if(view == remove_btn){
            AlertDialog.Builder adb = new AlertDialog.Builder(getActivity());
            adb.setTitle("Are you want to remove this data ?");
            adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    remove();
                }
            });
            adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    mListener.changeFragment(1);
                }
            });
            adb.show();
        }
    }
    private void setParams(){
        if(model == null) return;
        id = model.id;
        title_area.setText(model.title);
        place_area.setText(model.place);
        detail_area.setText(model.detail);
        date_area.setText(model.date);
        lat_area.setText(model.lat);
        lon_area.setText(model.lon);
        //load image
        if(model.image != null && !model.image.isEmpty()){
            Glide.with(getActivity())
                    .load(model.image)
                    .into(image_view);
        }
        title_area.setEnabled(false);
        place_area.setEnabled(false);
        detail_area.setEnabled(false);
        //map_show_btn.setVisibility(View.GONE);
        camera_btn.setVisibility(View.GONE);
        share_btn.setVisibility(View.GONE);
        remove_btn.setVisibility(View.VISIBLE);
    }
    //set date form date picker
    private void setDate(){
        DatePickerDialog birthday_selection = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                date_area.setText(date_format.format(newDate.getTime()));
            }

        }, newCalenda.get(Calendar.YEAR), newCalenda.get(Calendar.MONTH), newCalenda.get(Calendar.DAY_OF_MONTH));
        birthday_selection.show();
    }
    //take photo from camera
    private void takePictureFromCamera(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 3);
            }else{
                Intent cameraIntent = new  Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 3: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent cameraIntent = new  Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }
                return;
            }

        }
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //create app storage using current day
        String save_storage_path = StorageController.createAppStorage();
        if(save_storage_path == null){
            image_path = "";
            Toast.makeText(getActivity(), "Fail to save image !", Toast.LENGTH_LONG).show();
            return;
        }
        image_path = save_storage_path + File.separator + StorageController.getCurrentTime() + ".png";
        File destFile = new File(image_path);

       if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Bitmap photo_bitmap = (Bitmap) data.getExtras().get("data");//this is your bitmap image and now you can do whatever you want with this
            image_view.setImageBitmap(photo_bitmap);
            try {
                FileOutputStream out = new FileOutputStream(destFile);
                photo_bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.flush();
                out.close();
                Toast.makeText(getActivity(), "Success to save image !", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                image_path = "";
                e.printStackTrace();
                Toast.makeText(getActivity(), "Fail to save image !", Toast.LENGTH_LONG).show();
            }
        }
    }
    //save all entered data to database
    private void save(){
        String title = title_area.getText().toString() == null ? "" : title_area.getText().toString();
        String place = place_area.getText().toString() == null ? "" : place_area.getText().toString();
        String detail = detail_area.getText().toString() == null ? "" : detail_area.getText().toString();
        String date = date_area.getText().toString() == null ? "" : date_area.getText().toString();
        String lat = lat_area.getText().toString() == null ? "" : lat_area.getText().toString();
        String lon = lon_area.getText().toString() == null ? "" : lon_area.getText().toString();
        String image = image_path == null ? "" : image_path;
        if(title == null || title.isEmpty()){
            Toast.makeText(getActivity(), "Enter Title !", Toast.LENGTH_LONG).show();
            return;
        }
        if(place == null || place.isEmpty()){
            Toast.makeText(getActivity(), "Enter Place !", Toast.LENGTH_LONG).show();
            return;
        }
        if(date == null || date.isEmpty()){
            Toast.makeText(getActivity(), "Enter Date !", Toast.LENGTH_LONG).show();
            return;
        }
        if(db.insertContact(title, place, detail, date, lat, lon, image) > 0){
            Toast.makeText(getActivity(), "Success to save data !", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getActivity(), "Fail to save data !", Toast.LENGTH_LONG).show();
        }
        mListener.changeFragment(1);

    }
    //remove data
    private void remove(){
        if(id < 0){
            Toast.makeText(getActivity(), "Fail to remove data !", Toast.LENGTH_LONG).show();
        }else{
            int rst = db.deleteContact(id);
            Toast.makeText(getActivity(), "Success to remove data !", Toast.LENGTH_LONG).show();
        }
        mListener.changeFragment(1);
    }
    //show map position
    private void showMap(){
        Intent intent = new Intent(getActivity(), MapsActivity.class);
        intent.putExtra("lat", lat_area.getText().toString());
        intent.putExtra("lon", lon_area.getText().toString());
        getActivity().startActivity(intent);
    }
    //get current location
    private Location getLastBestLocation() {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        Location locationGPS = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        Location locationNet = mLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        long GPSLocationTime = 0;
        if (null != locationGPS) { GPSLocationTime = locationGPS.getTime(); }

        long NetLocationTime = 0;

        if (null != locationNet) {
            NetLocationTime = locationNet.getTime();
        }

        if ( 0 < GPSLocationTime - NetLocationTime ) {
            return locationGPS;
        }
        else {
            return locationNet;
        }
    }
    //get current day
    private String getCurrentDay(){
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        Date now = new Date();
        return format.format(now);
    }
}
