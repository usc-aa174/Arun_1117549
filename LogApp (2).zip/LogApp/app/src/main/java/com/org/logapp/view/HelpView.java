package com.org.logapp.view;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.org.logapp.R;

public class HelpView extends AppCompatActivity implements View.OnClickListener {
    WebView help_view;
    ImageView back_action;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_view);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.custom_action_bar);
        View view = getSupportActionBar().getCustomView();
        back_action = view.findViewById(R.id.action_bar_img_1);
        back_action.setImageResource(R.drawable.ic_arrow_back_black_24dp);
        back_action.setOnClickListener(this);

        help_view = findViewById(R.id.help_view);
        help_view.loadUrl("https://www.wikihow.com/Check-In-on-Facebook");

        // this will enable the javascipt.
        help_view.getSettings().setJavaScriptEnabled(true);

        // WebViewClient allows you to handle
        // onPageFinished and override Url loading.
        help_view.setWebViewClient(new WebViewClient());
    }
    public void onClick(View view){
        if(view == back_action){
            finish();
        }
    }
}
