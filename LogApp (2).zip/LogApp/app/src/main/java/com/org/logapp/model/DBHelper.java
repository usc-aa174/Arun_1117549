package com.org.logapp.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Receipt.db";
    public static final String CONTACTS_TABLE_NAME = "contacts";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table contacts " +
                        "(id integer primary key AUTOINCREMENT NOT NULL, title text,place text,detail text, date text,lat text,lon text,image text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public long insertContact (String title, String place, String detail, String date,String lat, String lon, String image) {
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("title", title);
            contentValues.put("place", place);
            contentValues.put("detail", detail);
            contentValues.put("date", date);
            contentValues.put("lat", lat);
            contentValues.put("lon", lon);
            contentValues.put("image", image);
            long id = db.insert(CONTACTS_TABLE_NAME, null, contentValues);
            return id;
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }

    public DataModel getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from contacts where id="+id+"", null );
        if(res != null){
            String title = res.getString(res.getColumnIndex("title"));
            String place = res.getString(res.getColumnIndex("place"));
            String detail = res.getString(res.getColumnIndex("detail"));
            String date = res.getString(res.getColumnIndex("date"));
            String lat = res.getString(res.getColumnIndex("lat"));
            String lon = res.getString(res.getColumnIndex("lon"));
            String image = res.getString(res.getColumnIndex("image"));

            DataModel model = new DataModel(id, title, place, detail, date, lat, lon, image);
            return model;
        }else return null;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }

    public boolean updateContact (Integer id, String title, String place, String detail, String date,String lat, String lon, String image) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("place", place);
        contentValues.put("detail", detail);
        contentValues.put("date", date);
        contentValues.put("lat", lat);
        contentValues.put("lon", lon);
        contentValues.put("image", image);
        db.update(CONTACTS_TABLE_NAME, contentValues, "id = ? ", new String[] { Integer.toString(id) } );
        return true;
    }

    public Integer deleteContact (Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(CONTACTS_TABLE_NAME,
                "id = ? ",
                new String[] { Integer.toString(id) });
    }

    public ArrayList<DataModel> getAll() {
        ArrayList<DataModel> array_list = new ArrayList<DataModel>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from " + CONTACTS_TABLE_NAME, null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            int id = res.getInt(res.getColumnIndex("id"));
            String title = res.getString(res.getColumnIndex("title"));
            String place = res.getString(res.getColumnIndex("place"));
            String detail = res.getString(res.getColumnIndex("detail"));
            String date = res.getString(res.getColumnIndex("date"));
            String lat = res.getString(res.getColumnIndex("lat"));
            String lon = res.getString(res.getColumnIndex("lon"));
            String image = res.getString(res.getColumnIndex("image"));

            DataModel model = new DataModel(id, title, place, detail, date, lat, lon, image);
            array_list.add(model);
            res.moveToNext();
        }
        return array_list;
    }
}
