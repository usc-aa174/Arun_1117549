package com.org.logapp.view;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.org.logapp.R;
import com.org.logapp.model.DBHelper;
import com.org.logapp.model.DataModel;
import com.org.logapp.controller.listAdapter;

import java.util.ArrayList;

public class ListUI extends Fragment implements View.OnClickListener {
    ListView log_list;
    private ArrayList<DataModel> dataList = new ArrayList<DataModel>();


    listAdapter list_adapter;
    DBHelper db;
    public ListUI() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.activity_list_ui_view, container, false);
        log_list = view.findViewById(R.id.log_list);

        db = new DBHelper(getActivity());
        list_adapter = new listAdapter(getActivity(), R.id.log_list, db.getAll());
        log_list.setAdapter(list_adapter);
        return view;
    }
    public void onClick(View view){

    }
}
