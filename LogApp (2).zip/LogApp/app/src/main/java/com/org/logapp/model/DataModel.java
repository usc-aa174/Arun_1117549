package com.org.logapp.model;

public class DataModel {
    public int id;
    public String title;
    public String place;
    public String detail;
    public String date;
    public String lat;
    public String lon;
    public String image;

    public DataModel(int id, String title, String place, String detail, String date, String lat, String lon, String image){
        this.id = id;
        this.title = title;
        this.place = place;
        this.detail = detail;
        this.date = date;
        this.lat = lat;
        this.lon = lon;
        this.image = image;
    }
}
