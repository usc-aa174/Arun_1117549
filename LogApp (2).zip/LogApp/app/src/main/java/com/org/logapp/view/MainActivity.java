package com.org.logapp.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.org.logapp.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, OnFragmentInteractionListener {
    TextView menu_text;
    ImageView new_view;
    ImageView help_view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_view);

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.custom_action_bar);
        View view = getSupportActionBar().getCustomView();
        menu_text = view.findViewById(R.id.menu_text);
        new_view = view.findViewById(R.id.action_bar_img_1);
        new_view.setImageResource(R.drawable.ic_add_circle_black_24dp);
        new_view.setTag(R.drawable.ic_add_circle_black_24dp);
        help_view = view.findViewById(R.id.action_bar_img_2);
        help_view.setImageResource(R.drawable.ic_help_black_24dp);
        new_view.setOnClickListener(this);
        help_view.setOnClickListener(this);

        addFragment(new ListUI());

        getLocationPermission();
    }
    public void onClick(View view){
        if(view == new_view){
            if((Integer)new_view.getTag() == R.drawable.ic_add_circle_black_24dp){
                new_view.setImageResource(R.drawable.ic_arrow_back_black_24dp);
                new_view.setTag(R.drawable.ic_arrow_back_black_24dp);
                ItemUI.flag = true;
                addFragment(new ItemUI());
            }else if((Integer)new_view.getTag() == R.drawable.ic_arrow_back_black_24dp){
                new_view.setImageResource(R.drawable.ic_add_circle_black_24dp);
                new_view.setTag(R.drawable.ic_add_circle_black_24dp);
                addFragment(new ListUI());
            }

        }else if(view == help_view){
            Intent intent = new Intent(this, HelpView.class);
            startActivity(intent);
        }
    }
    public void addFragment(Fragment fragmentg) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        ft.replace(R.id.frame_container, fragmentg);
        ft.commitAllowingStateLoss();
    }
    @Override
    public void changeFragment(int id){
        if (id == 1) {
            new_view.setImageResource(R.drawable.ic_add_circle_black_24dp);
            new_view.setTag(R.drawable.ic_add_circle_black_24dp);
            Fragment list_ui = new ListUI();
            addFragment(list_ui);
        }
        else if (id == 2) {
            new_view.setImageResource(R.drawable.ic_arrow_back_black_24dp);
            new_view.setTag(R.drawable.ic_arrow_back_black_24dp);
            Fragment item_ui = new ItemUI();
            addFragment(item_ui);
        }
    }
    //get location permission
    private void getLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

            ActivityCompat.requestPermissions(MainActivity.this, permissions, 100);
        }
    }
    //get write permission
    private void getWritePermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 200);
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 100: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getWritePermission();
                }
                return;
            }
            case 200: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                }
                return;
            }

        }
    }
}
