package com.org.logapp.view;

public interface  OnFragmentInteractionListener {
    public void changeFragment(int id);
}
