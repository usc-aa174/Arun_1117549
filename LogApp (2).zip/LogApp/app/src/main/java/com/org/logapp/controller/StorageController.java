package com.org.logapp.controller;

import android.os.Environment;

import java.io.File;

public class StorageController {
    private static String app_storage_name = "Receipt";

    public static String createAppStorage(){
        File root_storage = Environment.getExternalStorageDirectory();
        File app_storage = new File(root_storage + File.separator + app_storage_name + File.separator);
        if (!app_storage.exists()) {
            if(app_storage.mkdirs()){
                return app_storage.getAbsolutePath();
            }else return null;
        }
        return app_storage.getAbsolutePath();
    }
    public static String getCurrentTime(){
        return String.valueOf(System.currentTimeMillis());
    }
}
